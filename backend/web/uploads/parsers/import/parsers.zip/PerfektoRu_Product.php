<?php
//Парсинг карточки товара
namespace common\models\parsers;

use Yii;
use \phpQuery;

use common\models\parsers\classes\ParserProduct;
use common\models\parsers\classes\ParserPagination;
use common\models\Error;

class PerfektoRu_Product extends ParserProduct
{

    //Парсинг списка 
    public function actionParsList($action)
    {
        
        $data=parent::parsPage();
        $base_url=parse_url($action->example_url, PHP_URL_SCHEME).'://'.parse_url($action->example_url, PHP_URL_HOST);
        
        //Парсинг списка
        $items=$this->document->find('.wrapper-catalog .col-item');
        foreach ($items as $key => $item) {
            $model= new ParserProduct();
            
            // --- Begin of parse item
            $model->id='N/A';
            $model->name=pq($item)->find('a.productClick')->text();
            $model->viewUrl=$base_url.pq($item)->find('a.productClick')->attr('href');
            $model->price=intval(str_replace(' ', '', str_replace('руб.', '',pq($item)->find('.price')->text())) );
            $model->currency='RUR';
            // --- End of parse item
            

            if($model->validate()){
                $data['items'][]=$model->toArray();
            }else{
                $this->addError('actionParsList',Error::CODE_PARSING_ERROR);
                $this->addErrors($model->errors);
                return false;
            }
        }

        //Парсинг pagination
        $pages_selector='ul.pagination li';
        $pages=$this->document->find($pages_selector);
        foreach ($pages as $key => $item) {
            
            // --- Begin of parse page
            $page = new ParserPagination();
            $page->title=pq($item)->find('a')->text();
            $page->url=$base_url.pq($item)->find('a')->attr('href');
            // --- End of parse page
            
            if($page->validate()){
                $data['pages'][]=$page->toArray();
            }else{
                $this->addError('actionParsList',Error::CODE_PARSING_ERROR);
                return false;
            }
        }
        return json_encode($data,JSON_UNESCAPED_UNICODE);
        
    }
    
    //Парсинг записи 
    public function actionParsItem($action)
    {

        $data=parent::parsPage();

        $item=$this->document->find('.product.col-md-12');
        
        // --- Begin of parse item
        $this->id='N/A';
        $this->name=$this->document->find('h1.title')->text();
        $this->price=intval(str_replace(' ', '', str_replace('руб.', '',pq($item)->find('.price.current')->text())) );
        $this->currency='RUR';
        // --- End of parse item

        if($this->validate()){
            $data=array_merge($data,$this->toArray());
            return json_encode($data,JSON_UNESCAPED_UNICODE);
        }else{
            $this->addError('actionParsItem',Error::CODE_PARSING_ERROR);
            return false;
        }
        
    }


}
