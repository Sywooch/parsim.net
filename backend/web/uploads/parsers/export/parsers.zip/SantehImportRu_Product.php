<?php
//Парсинг карточки товара
namespace common\models\parsers;

use Yii;
use \phpQuery;

use common\models\parsers\classes\ParserProduct;
use common\models\parsers\classes\ParserPagination;
use common\models\Error;

class SantehImportRu_Product extends ParserProduct
{

    //Парсинг списка 
    public function actionParsList($action)
    {
        
        $data=parent::parsPage();
        $base_url=parse_url($action->example_url, PHP_URL_SCHEME).'://'.parse_url($action->example_url, PHP_URL_HOST);
        
        //$model->priceCanZero=true;

        //Парсинг списка
        $items=$this->document->find('#goods-list ul li.teasers__i');
        foreach ($items as $key => $item) {
            $model= new ParserProduct();
            
            // --- Begin of parse item
            $model->id='N/A';
            $model->name=pq($item)->find('a.teaser__h div div')->text();
            $model->viewUrl=$base_url.pq($item)->find('a.teaser__h')->attr('href');
            $model->price=intval( preg_replace('/[a-zA-Zа-яА-Я\s]+/u', '', pq($item)->find('div.teaser__price-now')->text()) );
            $model->currency=preg_replace('/^[0-9\s+]/', '',pq($item)->find('div.teaser__price-now span:eq(1)')->text() );
            // --- End of parse item
            

            if($model->validate()){
                $data['items'][]=$model->toArray();
            }else{
                $this->addError('actionParsList',Error::CODE_PARSING_ERROR);
                $this->addErrors($model->errors);

                //$this->addError('price',preg_replace('/[а-яА-Я\s]+/u', '', pq($item)->find('div.teaser__price-now')->text()).' '.$model->name );

                return false;
            }
        }

        //Парсинг pagination
        $pages_selector='ul.pagination li';
        $pages=$this->document->find($pages_selector);
        foreach ($pages as $key => $item) {
            
            // --- Begin of parse page
            $page = new ParserPagination();
            $page->title=pq($item)->find('a')->text();
            $page->url=$base_url.pq($item)->find('a')->attr('href');
            // --- End of parse page
            
            if($page->validate()){
                $data['pages'][]=$page->toArray();
            }else{
                $this->addError('actionParsList',Error::CODE_PARSING_ERROR);
                return false;
            }
        }
        return json_encode($data,JSON_UNESCAPED_UNICODE);
        
    }
    
    //Парсинг записи 
    public function actionParsItem($action)
    {

        $data=parent::parsPage();

        $item=$this->document->find('#detail-goods div[itemtype="http://schema.org/Product"]');
        
        // --- Begin of parse item
        $this->id=pq($item)->find('meta[itemprop="sku"]')->attr('content');
        $this->name=pq($item)->find('h1')->text();
        $this->price=intval(preg_replace('/[^\w_]+/u', '',pq($item)->find('meta[itemprop="price"]')->attr('content')) );
        $this->currency=preg_replace('/^[0-9\s+]/', '',pq($item)->find('meta[itemprop="priceCurrency"]')->attr('content') );
        // --- End of parse item

        if($this->validate()){
            $data=array_merge($data,$this->toArray());
            return json_encode($data,JSON_UNESCAPED_UNICODE);
        }else{
            $this->addError('actionParsItem',Error::CODE_PARSING_ERROR);
            return false;
        }
        
    }


}
